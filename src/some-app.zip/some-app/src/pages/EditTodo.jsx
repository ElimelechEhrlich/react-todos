import React from 'react'
import { useParams } from 'react-router'

export default function EditTodo() {
  const { id } = useParams();
  console.log(id)
  return (
    <div>EditTodo</div>
  )
}
