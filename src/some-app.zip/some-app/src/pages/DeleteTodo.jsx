import React from 'react'

export default function DeleteTodo() {
  return (
    <div>DeleteTodo</div>
  )
}
