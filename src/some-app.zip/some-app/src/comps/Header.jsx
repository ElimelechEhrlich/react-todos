import React from 'react'
import { Link } from 'react-router'

export default function Header() {
  return (
    <div className='h-[10vh] bg-[#908b8ba3] rounded-b-2xl shadow-md flex items-center justify-between px-[40px]'>
        <div className='flex items-center gap-3'>
            <img className='object-cover w-40 h-20 rounded-3xl' src="https://static.vecteezy.com/system/resources/thumbnails/041/880/991/small/ai-generated-pic-artistic-depiction-of-sunflowers-under-a-vast-cloudy-sky-photo.jpg" alt="" />
            <Link className='hover:text-[blue]' to="/">Home</Link>
        </div>
        <Link className='hover:text-[blue]' to="/AddTodo">Add</Link>
    </div>
  )
}
